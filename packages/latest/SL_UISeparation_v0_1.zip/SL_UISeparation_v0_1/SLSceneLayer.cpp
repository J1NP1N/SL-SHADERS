#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#define IMGUI_DISABLE_INCLUDE_IMCONFIG_H

#include <windows.h>
#include <GL/gl.h>

#include <imgui.h>
#include <reshade.hpp>

#include "SLSceneStateTracking.hpp"

#include <atomic>
#include <cstdint>
#include <cstring>

namespace api = reshade::api;

namespace
{
    constexpr GLenum GL_CURRENT_PROGRAM_VALUE = 0x8B8D;
    constexpr GLenum GL_DRAW_FRAMEBUFFER_BINDING_VALUE = 0x8CA6;

    using pfn_gl_get_uniform_location = GLint(APIENTRY *)(GLuint, const char *);
    pfn_gl_get_uniform_location p_glGetUniformLocation = nullptr;

    template <typename T>
    T load_gl_proc(const char *name)
    {
        PROC proc = wglGetProcAddress(name);
        if (proc == nullptr ||
            proc == reinterpret_cast<PROC>(1) ||
            proc == reinterpret_cast<PROC>(2) ||
            proc == reinterpret_cast<PROC>(3) ||
            proc == reinterpret_cast<PROC>(-1))
        {
            HMODULE module = GetModuleHandleW(L"opengl32.dll");
            if (module == nullptr)
                module = LoadLibraryW(L"opengl32.dll");
            if (module != nullptr)
                proc = GetProcAddress(module, name);
        }
        return reinterpret_cast<T>(proc);
    }

    struct frame_snapshot
    {
        bool boundary_detected = false;
        bool effects_moved = false;
        bool had_post_scene_draw = false;
        bool runtime_views_ready = false;
        GLuint final_program = 0;
        GLint viewport[4] = { 0, 0, 0, 0 };
        uint32_t first_post_scene_vertices = 0;
    };

    struct __declspec(uuid("B87F6FB9-B71C-493A-A84D-7EA1ED3070CE")) device_data
    {
        api::effect_runtime *runtime = nullptr;

        api::resource_view backbuffer_rtv = { 0 };
        api::resource_view backbuffer_rtv_srgb = { 0 };
        bool runtime_views_ready = false;

        bool boundary_pending = false;
        bool boundary_detected_this_frame = false;
        bool effects_moved_this_frame = false;
        bool had_post_scene_draw_this_frame = false;

        GLuint final_program = 0;
        GLint final_viewport[4] = { 0, 0, 0, 0 };
        uint32_t first_post_scene_vertices = 0;

        uint64_t boundary_count = 0;
        uint64_t moved_count = 0;
        uint64_t warmup_frames = 0;
        uint64_t no_post_scene_draw_frames = 0;

        frame_snapshot last;
    };

    std::atomic_bool g_inside_reshade_effects{ false };
    std::atomic_bool g_manual_render{ false };
    bool g_enabled = true;

    bool load_required_gl()
    {
        if (p_glGetUniformLocation != nullptr)
            return true;
        p_glGetUniformLocation =
            load_gl_proc<pfn_gl_get_uniform_location>("glGetUniformLocation");
        return p_glGetUniformLocation != nullptr;
    }

    bool is_firestorm_final_scene_present(
        uint32_t vertices,
        uint32_t instances,
        GLuint &program_out,
        GLint (&viewport_out)[4])
    {
        if (vertices != 3 || instances != 1 || !load_required_gl())
            return false;

        GLint fbo = -1;
        glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING_VALUE, &fbo);
        if (fbo != 0)
            return false;

        GLint program = 0;
        glGetIntegerv(GL_CURRENT_PROGRAM_VALUE, &program);
        if (program <= 0)
            return false;

        // Firestorm's final scene presentation shader is the
        // Deferred Post NoDoF Noise shader. Its fragment shader declares
        // diffuseRect, depthMap and screen_res. The same shader can be used
        // for off-screen copies, so FBO 0 + fullscreen triangle is part of
        // the signature too.
        if (p_glGetUniformLocation(static_cast<GLuint>(program), "diffuseRect") < 0 ||
            p_glGetUniformLocation(static_cast<GLuint>(program), "depthMap") < 0 ||
            p_glGetUniformLocation(static_cast<GLuint>(program), "screen_res") < 0)
            return false;

        GLint viewport[4] = { 0, 0, 0, 0 };
        glGetIntegerv(GL_VIEWPORT, viewport);
        if (viewport[2] <= 1 || viewport[3] <= 1)
            return false;

        program_out = static_cast<GLuint>(program);
        std::memcpy(viewport_out, viewport, sizeof(viewport));
        return true;
    }

    device_data *get_device_data(api::command_list *cmd_list)
    {
        if (cmd_list == nullptr)
            return nullptr;
        api::device *const device = cmd_list->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return nullptr;
        return device->get_private_data<device_data>();
    }

    void run_effects_before_current_ui_draw(
        api::command_list *cmd_list,
        device_data &data,
        uint32_t current_vertices)
    {
        if (!g_enabled ||
            !data.boundary_pending ||
            data.effects_moved_this_frame ||
            data.runtime == nullptr)
            return;

        data.had_post_scene_draw_this_frame = true;
        data.first_post_scene_vertices = current_vertices;

        // Let one normal ReShade present happen after runtime creation/resize.
        // That gives us ReShade's exact non-sRGB and sRGB backbuffer views.
        // They stay valid until the effect runtime is recreated.
        if (!data.runtime_views_ready ||
            data.backbuffer_rtv == 0 ||
            data.backbuffer_rtv_srgb == 0)
        {
            data.boundary_pending = false;
            ++data.warmup_frames;
            return;
        }

        sl_scene_state_tracking *tracked =
            cmd_list->get_private_data<sl_scene_state_tracking>();
        if (tracked == nullptr)
        {
            data.boundary_pending = false;
            return;
        }

        // ReShade's render_effects call may alter application GL state.
        // Save the Firestorm state that exists immediately before the first
        // UI/HUD draw, run effects on the real backbuffer, then restore it.
        const sl_scene_state_block saved_state = *tracked;

        g_manual_render.store(true, std::memory_order_relaxed);
        g_inside_reshade_effects.store(true, std::memory_order_relaxed);

        data.runtime->render_effects(
            cmd_list,
            data.backbuffer_rtv,
            data.backbuffer_rtv_srgb);

        g_inside_reshade_effects.store(false, std::memory_order_relaxed);
        g_manual_render.store(false, std::memory_order_relaxed);

        saved_state.apply(cmd_list);

        data.effects_moved_this_frame = true;
        data.boundary_pending = false;
        ++data.moved_count;
    }

    void inspect_application_draw(
        api::command_list *cmd_list,
        uint32_t vertices,
        uint32_t instances)
    {
        if (g_inside_reshade_effects.load(std::memory_order_relaxed))
            return;

        device_data *const data = get_device_data(cmd_list);
        if (data == nullptr)
            return;

        // If the previous application draw was Firestorm's final scene
        // presentation, this callback belongs to the first subsequent
        // HUD/UI draw. ReShade effects must execute before that draw.
        run_effects_before_current_ui_draw(cmd_list, *data, vertices);

        if (!g_enabled || data->effects_moved_this_frame)
            return;

        GLuint program = 0;
        GLint viewport[4] = { 0, 0, 0, 0 };
        if (is_firestorm_final_scene_present(
                vertices,
                instances,
                program,
                viewport))
        {
            data->boundary_pending = true;
            data->boundary_detected_this_frame = true;
            data->final_program = program;
            std::memcpy(data->final_viewport, viewport, sizeof(viewport));
            ++data->boundary_count;
        }
    }

    bool on_draw(
        api::command_list *cmd_list,
        uint32_t vertices,
        uint32_t instances,
        uint32_t,
        uint32_t)
    {
        inspect_application_draw(cmd_list, vertices, instances);
        return false;
    }

    bool on_draw_indexed(
        api::command_list *cmd_list,
        uint32_t indices,
        uint32_t instances,
        uint32_t,
        int32_t,
        uint32_t)
    {
        // The Firestorm final scene presentation is glDrawArrays with a
        // three-vertex fullscreen triangle, but indexed UI draws can be the
        // first draw after it and therefore still trigger the pre-UI handoff.
        inspect_application_draw(cmd_list, indices, instances);
        return false;
    }

    void on_init_device(api::device *device)
    {
        if (device != nullptr && device->get_api() == api::device_api::opengl)
            device->create_private_data<device_data>();
    }

    void on_destroy_device(api::device *device)
    {
        if (device != nullptr && device->get_api() == api::device_api::opengl)
            device->destroy_private_data<device_data>();
    }

    void on_init_effect_runtime(api::effect_runtime *runtime)
    {
        if (runtime == nullptr)
            return;
        api::device *const device = runtime->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        if (device_data *const data = device->get_private_data<device_data>())
        {
            data->runtime = runtime;
            data->backbuffer_rtv = { 0 };
            data->backbuffer_rtv_srgb = { 0 };
            data->runtime_views_ready = false;
        }
    }

    void on_destroy_effect_runtime(api::effect_runtime *runtime)
    {
        if (runtime == nullptr)
            return;
        api::device *const device = runtime->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        if (device_data *const data = device->get_private_data<device_data>())
        {
            if (data->runtime == runtime)
            {
                data->runtime = nullptr;
                data->backbuffer_rtv = { 0 };
                data->backbuffer_rtv_srgb = { 0 };
                data->runtime_views_ready = false;
            }
        }
    }

    void on_begin_effects(
        api::effect_runtime *runtime,
        api::command_list *,
        api::resource_view rtv,
        api::resource_view rtv_srgb)
    {
        g_inside_reshade_effects.store(true, std::memory_order_relaxed);

        if (runtime == nullptr ||
            g_manual_render.load(std::memory_order_relaxed))
            return;

        api::device *const device = runtime->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        if (device_data *const data = device->get_private_data<device_data>())
        {
            if (data->runtime == runtime && rtv != 0 && rtv_srgb != 0)
            {
                data->backbuffer_rtv = rtv;
                data->backbuffer_rtv_srgb = rtv_srgb;
                data->runtime_views_ready = true;
            }
        }
    }

    void on_finish_effects(
        api::effect_runtime *,
        api::command_list *,
        api::resource_view,
        api::resource_view)
    {
        // render_effects() invokes this event too. The explicit manual guard
        // remains set by the caller until render_effects returns.
        g_inside_reshade_effects.store(false, std::memory_order_relaxed);
    }

    void on_present(
        api::command_queue *,
        api::swapchain *swapchain,
        const api::rect *,
        const api::rect *,
        uint32_t,
        const api::rect *)
    {
        if (swapchain == nullptr)
            return;
        api::device *const device = swapchain->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        device_data *const data = device->get_private_data<device_data>();
        if (data == nullptr)
            return;

        data->last.boundary_detected = data->boundary_detected_this_frame;
        data->last.effects_moved = data->effects_moved_this_frame;
        data->last.had_post_scene_draw = data->had_post_scene_draw_this_frame;
        data->last.runtime_views_ready = data->runtime_views_ready;
        data->last.final_program = data->final_program;
        std::memcpy(data->last.viewport, data->final_viewport, sizeof(data->last.viewport));
        data->last.first_post_scene_vertices = data->first_post_scene_vertices;

        if (data->boundary_detected_this_frame &&
            !data->had_post_scene_draw_this_frame &&
            !data->effects_moved_this_frame)
        {
            ++data->no_post_scene_draw_frames;
        }

        data->boundary_pending = false;
        data->boundary_detected_this_frame = false;
        data->effects_moved_this_frame = false;
        data->had_post_scene_draw_this_frame = false;
        data->final_program = 0;
        std::memset(data->final_viewport, 0, sizeof(data->final_viewport));
        data->first_post_scene_vertices = 0;
    }

    void draw_overlay(api::effect_runtime *runtime)
    {
        if (runtime == nullptr)
            return;

        api::device *const device = runtime->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
        {
            ImGui::TextUnformatted("SL Scene Layer is OpenGL-only.");
            return;
        }

        device_data *const data = device->get_private_data<device_data>();
        if (data == nullptr)
            return;

        ImGui::Checkbox("Move ReShade effects before Firestorm UI", &g_enabled);
        ImGui::Separator();

        ImGui::Text("ReShade backbuffer views: %s",
            data->runtime_views_ready ? "READY" : "WARMING UP");
        ImGui::Text("Last frame scene boundary: %s",
            data->last.boundary_detected ? "YES" : "no");
        ImGui::Text("Last frame effects before UI: %s",
            data->last.effects_moved ? "YES" : "no");
        ImGui::Text("Post-scene application draw: %s",
            data->last.had_post_scene_draw ? "YES" : "no");

        if (data->last.boundary_detected)
        {
            ImGui::Text("Firestorm final program: %u", data->last.final_program);
            ImGui::Text(
                "World viewport: %d, %d  %d x %d",
                data->last.viewport[0],
                data->last.viewport[1],
                data->last.viewport[2],
                data->last.viewport[3]);
        }

        ImGui::Separator();
        ImGui::Text("Boundaries detected: %llu",
            static_cast<unsigned long long>(data->boundary_count));
        ImGui::Text("Frames moved before UI: %llu",
            static_cast<unsigned long long>(data->moved_count));
        ImGui::Text("Warm-up frames: %llu",
            static_cast<unsigned long long>(data->warmup_frames));
        ImGui::Text("Boundary with no later draw: %llu",
            static_cast<unsigned long long>(data->no_post_scene_draw_frames));

        ImGui::Separator();
        ImGui::PushTextWrapPos();
        ImGui::TextUnformatted(
            "Expected behavior: the first normal frame after load/resize warms up ReShade's exact backbuffer views. "
            "After that, this add-on recognizes Firestorm's final Deferred Post NoDoF Noise fullscreen scene draw and runs ReShade effects immediately before Firestorm's first HUD/UI draw. "
            "The normal end-of-frame ReShade effect pass is suppressed automatically by render_effects().");
        ImGui::PopTextWrapPos();
    }
}

extern "C" __declspec(dllexport)
const char *NAME = "SL Scene Layer";

extern "C" __declspec(dllexport)
const char *DESCRIPTION =
    "Moves ReShade effects to Firestorm's post-scene/pre-UI boundary.";

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        if (!reshade::register_addon(module))
            return FALSE;

        // Register state tracking before our callbacks, matching ReShade's
        // official effects_during_frame example.
        sl_scene_state_tracking::register_events();

        reshade::register_event<reshade::addon_event::init_device>(on_init_device);
        reshade::register_event<reshade::addon_event::destroy_device>(on_destroy_device);
        reshade::register_event<reshade::addon_event::init_effect_runtime>(on_init_effect_runtime);
        reshade::register_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_effect_runtime);
        reshade::register_event<reshade::addon_event::draw>(on_draw);
        reshade::register_event<reshade::addon_event::draw_indexed>(on_draw_indexed);
        reshade::register_event<reshade::addon_event::present>(on_present);
        reshade::register_event<reshade::addon_event::reshade_begin_effects>(on_begin_effects);
        reshade::register_event<reshade::addon_event::reshade_finish_effects>(on_finish_effects);

        reshade::register_overlay("SL Scene Layer", draw_overlay);
        break;

    case DLL_PROCESS_DETACH:
        reshade::unregister_overlay("SL Scene Layer", draw_overlay);

        reshade::unregister_event<reshade::addon_event::reshade_finish_effects>(on_finish_effects);
        reshade::unregister_event<reshade::addon_event::reshade_begin_effects>(on_begin_effects);
        reshade::unregister_event<reshade::addon_event::present>(on_present);
        reshade::unregister_event<reshade::addon_event::draw_indexed>(on_draw_indexed);
        reshade::unregister_event<reshade::addon_event::draw>(on_draw);
        reshade::unregister_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_effect_runtime);
        reshade::unregister_event<reshade::addon_event::init_effect_runtime>(on_init_effect_runtime);
        reshade::unregister_event<reshade::addon_event::destroy_device>(on_destroy_device);
        reshade::unregister_event<reshade::addon_event::init_device>(on_init_device);

        sl_scene_state_tracking::unregister_events();
        reshade::unregister_addon(module);
        break;
    }

    return TRUE;
}
