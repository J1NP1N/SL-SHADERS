#include "ReShade.fxh"

uniform float SL_UIBoundary_Test_Strength
<
    ui_label = "Scene-only tint strength";
    ui_tooltip = "Diagnostic only. With SL Scene Layer working, the 3D scene turns green/desaturated while Firestorm HUDs, floaters and viewer UI keep their original colors.";
    ui_type = "drag";
    ui_min = 0.0;
    ui_max = 1.0;
    ui_step = 0.01;
> = 0.75;

float4 SL_UIBoundary_Test_PS(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float4 color = tex2D(ReShade::BackBuffer, uv);
    float luma = dot(color.rgb, float3(0.2126, 0.7152, 0.0722));
    float3 proof = float3(luma * 0.18, luma, luma * 0.18);
    color.rgb = lerp(color.rgb, proof, SL_UIBoundary_Test_Strength);
    return color;
}

technique SL_UIBoundary_Test
<
    ui_label = "SL UI Boundary Test";
    ui_tooltip = "Diagnostic: strongly tints only the image region processed by ReShade. Firestorm UI should be drawn afterward and remain untinted.";
>
{
    pass
    {
        VertexShader = PostProcessVS;
        PixelShader = SL_UIBoundary_Test_PS;
    }
}
