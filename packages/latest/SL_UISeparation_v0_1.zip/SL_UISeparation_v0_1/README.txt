SL UI Separation v0.1
=====================

Purpose
-------
Moves ReShade effect execution to Firestorm's real post-scene / pre-UI boundary.
This is not a pixel mask and does not attempt to identify UI from final colors.

Source-grounded boundary
------------------------
Firestorm's current render order is:

  renderDeferredLighting()
    -> render_ui()
       -> gPipeline.renderFinalize()
          -> final Deferred Post NoDoF Noise fullscreen scene draw
          -> snapshot guides / focus point / debug overlays
       -> HUD elements
       -> HUD attachments
       -> 3D UI / name tags / selections
       -> 2D viewer UI / floaters / menus
       -> debug text

The add-on recognizes that final scene presentation draw on the default OpenGL
framebuffer. On the next Firestorm application draw callback it calls ReShade's
runtime->render_effects() BEFORE the draw executes, then restores Firestorm's GL
state. ReShade documents render_effects() specifically for moving effects to an
in-frame point such as before application UI and says it suppresses the normal
end-of-frame effect pass.

First-frame warmup
------------------
The first normal ReShade frame after load or resize is allowed through so the
add-on can learn ReShade's exact non-sRGB and sRGB backbuffer views. Separation
starts on following frames.

Test
----
1. Fully close Firestorm before installing because the .addon is loaded DLL code.
2. Install with the normal SL_InstallLatest.ps1 flow.
3. Launch Firestorm and open ReShade > Add-ons > SL Scene Layer.
4. Confirm:
       ReShade backbuffer views: READY
       Last frame scene boundary: YES
       Last frame effects before UI: YES
5. Enable "SL UI Boundary Test" in the ReShade effect list.

Expected result:
- 3D world is strongly green/desaturated.
- Viewer floaters, menus, chat UI, HUD attachments/name-tag style UI drawn after
  the scene boundary remain normal color.

If the world and UI are both tinted, send the SL Scene Layer diagnostic values.
If the world is not tinted, also send the ReShade log compile/error line.

Notes
-----
- OpenGL / Firestorm specific.
- This add-on intentionally does not change DEPTH, SL_NORMALS or SL_ALPHA_MASK.
- It does not patch HBAO or iMMERSE.
- State restore helper is adapted from crosire/reshade's official
  examples/utils/state_tracking code (BSD-3-Clause OR MIT).
