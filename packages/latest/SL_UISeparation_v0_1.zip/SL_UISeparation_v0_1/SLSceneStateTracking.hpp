/*
 * State tracking helper adapted from the official ReShade
 * examples/utils/state_tracking implementation.
 * Copyright (C) 2022 Patrick Mours
 * SPDX-License-Identifier: BSD-3-Clause OR MIT
 */
#pragma once

#include <reshade.hpp>

#include <unordered_map>
#include <utility>
#include <vector>

struct sl_scene_state_block
{
    void apply(reshade::api::command_list *cmd_list) const;
    void clear();

    std::vector<reshade::api::resource_view> render_targets;
    reshade::api::resource_view depth_stencil = { 0 };
    std::unordered_map<reshade::api::pipeline_stage, reshade::api::pipeline> pipelines;
    reshade::api::primitive_topology primitive_topology = reshade::api::primitive_topology::undefined;
    uint32_t blend_constant = 0;
    uint32_t sample_mask = 0xFFFFFFFFu;
    uint32_t front_stencil_reference_value = 0;
    uint32_t back_stencil_reference_value = 0;
    std::vector<reshade::api::viewport> viewports;
    std::vector<reshade::api::rect> scissor_rects;
    std::unordered_map<
        reshade::api::shader_stage,
        std::pair<reshade::api::pipeline_layout, std::vector<reshade::api::descriptor_table>>>
        descriptor_tables;
};

// Deliberately uses a project-specific UUID instead of ReShade's example UUID,
// so this add-on cannot collide with another add-on that also embeds the example.
class __declspec(uuid("7DA2C8A1-BC96-4EBF-A166-C4A844BCF67E")) sl_scene_state_tracking
    : public sl_scene_state_block
{
public:
    static void register_events();
    static void unregister_events();
};
