SL HBAO v0.5 - Smooth Photo AO
================================

Purpose
-------
v0.4 removed pixel-scale random AO rotation, which removed the fuzzy/grainy
look but exposed coherent directional blocks/banding.

v0.5 keeps everything that is already correct:
- Firestorm native normals
- clean pre-alpha SL_DEPTH
- Firestorm-derived SL_ALPHA_MASK
- confirmed world-viewport registration
- world-viewport projection math
- depth/normal-aware half-resolution upsample

Sampling change only
--------------------
- 16 AO directions instead of 12
- no independent per-pixel random rotation
- no fixed phase
- direction phase varies through a smooth low-frequency interpolated field
- default smooth phase variation: 0.70
- slightly less blur: 0.55

First test
----------
Enable:
    SL HBAO v0.5 - Smooth Photo AO

Disable v0.4 while testing.

Use defaults first.

Check:
    Display Mode = AO only
then:
    Display Mode = Final composite

Do NOT compensate with AO Radius or AO Strength if you still see blocks.
Send a screenshot instead; the next step would be a dedicated full-resolution
photo-quality AO path rather than hiding sampling structure with blur.
