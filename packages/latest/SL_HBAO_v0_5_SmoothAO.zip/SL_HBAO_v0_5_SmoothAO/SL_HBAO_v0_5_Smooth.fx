#include "ReShade.fxh"

// v0.5: smooth-sampling revision. Keeps the confirmed native normals, clean
// depth, Firestorm alpha coverage, world-viewport geometry and edge-aware
// upsample. Replaces both fixed-phase banding and pixel-scale random grain
// with a smoothly interpolated low-frequency phase field.

#define SL_AO_DIRECTIONS 16
#define SL_AO_MAX_STEPS 6

uniform float CameraVerticalFOV
<
    ui_label = "Camera Vertical FOV (degrees)";
    ui_type = "drag";
    ui_min = 20.0; ui_max = 120.0; ui_step = 0.1;
> = 60.0;

uniform float CameraNearPlane
<
    ui_label = "Camera Near Plane";
    ui_type = "drag";
    ui_min = 0.001; ui_max = 2.0; ui_step = 0.001;
> = 0.10;

uniform float CameraFarPlane
<
    ui_label = "Camera Far Plane";
    ui_type = "drag";
    ui_min = 16.0; ui_max = 2048.0; ui_step = 1.0;
> = 256.0;

// Set automatically by SLNativeBridge v0.4. Do not tune these by hand.
// Viewport is OpenGL window coordinates: x, y, width, height (origin bottom-left).
uniform float4 SLBridgeViewport = float4(0.0, 0.0, 1.0, 1.0);

// x/y = final ReShade backbuffer width/height
// z/w = native Firestorm deferred-buffer width/height
uniform float4 SLBridgeBufferInfo = float4(1.0, 1.0, 1.0, 1.0);

uniform float SLBridgeRegistrationValid = 0.0;

uniform float AORadius
<
    ui_label = "AO Radius (view units)";
    ui_type = "drag";
    ui_min = 0.01; ui_max = 2.0; ui_step = 0.01;
> = 0.18;

uniform float AOIntensity
<
    ui_label = "AO Strength";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 4.0; ui_step = 0.01;
> = 1.20;

uniform float AOBias
<
    ui_label = "AO Bias";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 0.50; ui_step = 0.005;
> = 0.08;

uniform int AOSteps
<
    ui_label = "AO Steps per Direction";
    ui_type = "slider";
    ui_min = 2; ui_max = SL_AO_MAX_STEPS;
> = 5;

uniform float AOMaxRadiusPixels
<
    ui_label = "AO Maximum Screen Radius";
    ui_type = "drag";
    ui_min = 8.0; ui_max = 192.0; ui_step = 1.0;
> = 72.0;

uniform float AODistanceFalloff
<
    ui_label = "AO Distance Falloff";
    ui_type = "drag";
    ui_min = 0.25; ui_max = 6.0; ui_step = 0.05;
> = 2.0;

uniform float AOPhaseVariation
<
    ui_label = "AO Smooth Phase Variation";
    ui_tooltip = "Smooth low-frequency rotation of the 16-direction pattern. Breaks directional blocks without pixel-scale film grain.";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 0.70;

uniform float BlurDepthSensitivity
<
    ui_label = "Blur Depth Edge Protection";
    ui_type = "drag";
    ui_min = 0.1; ui_max = 64.0; ui_step = 0.1;
> = 8.0;

uniform float BlurNormalSensitivity
<
    ui_label = "Blur Normal Edge Protection";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 64.0; ui_step = 0.5;
> = 12.0;

uniform float BlurStrength
<
    ui_label = "AO Blur Strength";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 0.55;


uniform float AlphaCoverageProtection
<
    ui_label = "Alpha Coverage AO Protection";
    ui_tooltip = "1.0 removes underlying opaque HBAO in proportion to Firestorm's actual accumulated alpha coverage.";
    ui_type = "drag";
    ui_min = 0.0; ui_max = 1.0; ui_step = 0.01;
> = 1.0;

uniform int DisplayMode
<
    ui_label = "Display Mode";
    ui_type = "combo";
    ui_items =
        "Final composite\0"
        "AO only\0"
        "Raw AO (before blur)\0"
        "Decoded native normals\0"
        "Linear depth\0"
        "Position diagnostic\0"
        "Bridge alignment overlay\0"
        "Firestorm alpha coverage\0";
> = 1;

uniform float DebugDepthRange
<
    ui_label = "Debug Depth Range";
    ui_type = "drag";
    ui_min = 0.25; ui_max = 512.0; ui_step = 0.25;
> = 10.0;

texture SLNativeNormalsTex : SL_NORMALS;
texture SLNativeDepthTex   : SL_DEPTH;
texture SLAlphaMaskTex     : SL_ALPHA_MASK;

sampler SLNativeNormalsSampler
{
    Texture = SLNativeNormalsTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = POINT;
    MagFilter = POINT;
    MipFilter = POINT;
};

sampler SLNativeDepthSampler
{
    Texture = SLNativeDepthTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = POINT;
    MagFilter = POINT;
    MipFilter = POINT;
};


sampler SLAlphaMaskSampler
{
    Texture = SLAlphaMaskTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = POINT;
    MagFilter = POINT;
    MipFilter = POINT;
};

texture SLAORawTex
{
    Width = BUFFER_WIDTH / 2;
    Height = BUFFER_HEIGHT / 2;
    Format = R16F;
};

sampler SLAORawSampler
{
    Texture = SLAORawTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = POINT;
};

texture SLAOBlurHTex
{
    Width = BUFFER_WIDTH / 2;
    Height = BUFFER_HEIGHT / 2;
    Format = R16F;
};

sampler SLAOBlurHSampler
{
    Texture = SLAOBlurHTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = POINT;
};

texture SLAOBlurVTex
{
    Width = BUFFER_WIDTH / 2;
    Height = BUFFER_HEIGHT / 2;
    Format = R16F;
};

sampler SLAOBlurVSampler
{
    Texture = SLAOBlurVTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = POINT;
};

bool HasBridgeRegistration()
{
    return SLBridgeRegistrationValid > 0.5 &&
           SLBridgeViewport.z > 1.0 &&
           SLBridgeViewport.w > 1.0 &&
           SLBridgeBufferInfo.x > 1.0 &&
           SLBridgeBufferInfo.y > 1.0;
}

float2 FirestormUV(float2 screenUV)
{
    if (!HasBridgeRegistration())
        return float2(-2.0, -2.0);

    float2 windowPxGL = float2(
        screenUV.x * SLBridgeBufferInfo.x,
        (1.0 - screenUV.y) * SLBridgeBufferInfo.y);

    return (windowPxGL - SLBridgeViewport.xy) / SLBridgeViewport.zw;
}

bool InsideFirestormWorld(float2 screenUV)
{
    float2 nativeUV = FirestormUV(screenUV);
    return nativeUV.x >= 0.0 && nativeUV.x <= 1.0 &&
           nativeUV.y >= 0.0 && nativeUV.y <= 1.0;
}

float3 DecodeFirestormNormalRaw(float4 encodedNormal)
{
    float2 fenc = encodedNormal.xy * 4.0 - 2.0;
    float f = dot(fenc, fenc);
    float g = sqrt(saturate(1.0 - f * 0.25));

    float3 n;
    n.xy = fenc * g;
    n.z = 1.0 - f * 0.5;

    float len2 = dot(n, n);
    if (len2 > 1e-8)
        return n * rsqrt(len2);
    return float3(0.0, 0.0, 1.0);
}

float3 GetFirestormNormal(float2 screenUV)
{
    return DecodeFirestormNormalRaw(tex2D(SLNativeNormalsSampler, FirestormUV(screenUV)));
}

float GetRawDepth(float2 screenUV)
{
    return tex2D(SLNativeDepthSampler, FirestormUV(screenUV)).r;
}


float GetFirestormAlphaCoverage(float2 screenUV)
{
    if (!InsideFirestormWorld(screenUV))
        return 0.0;

    return saturate(tex2D(SLAlphaMaskSampler, FirestormUV(screenUV)).a);
}

float LinearViewDistance(float rawDepth)
{
    float n = max(CameraNearPlane, 1e-5);
    float f = max(CameraFarPlane, n + 1e-3);
    float z = rawDepth * 2.0 - 1.0;
    return (2.0 * n * f) / max(f + n - z * (f - n), 1e-6);
}

float3 ReconstructViewPosition(float2 screenUV, float rawDepth)
{
    float d = LinearViewDistance(rawDepth);

    // Projection belongs ONLY to Firestorm's 3D world viewport.
    float aspect = SLBridgeViewport.z / max(SLBridgeViewport.w, 1.0);

    float tanHalfFov = tan(radians(CameraVerticalFOV) * 0.5);
    float2 nativeUV = FirestormUV(screenUV);
    float2 ndc = nativeUV * 2.0 - 1.0;

    return float3(
        ndc.x * d * aspect * tanHalfFov,
        ndc.y * d * tanHalfFov,
        -d);
}

bool IsBackgroundDepth(float d)
{
    return d >= 0.999999;
}

float PhaseHash(float2 p)
{
    // Deterministic scalar hash. It is sampled only on a coarse lattice and
    // smoothly interpolated, so it does NOT create pixel-scale AO grain.
    return frac(
        sin(dot(p, float2(127.1, 311.7))) *
        43758.5453123);
}

float SmoothPhase01(float2 pixelCoord)
{
    // pixelCoord here is the AO render-target pixel coordinate. A 12-pixel
    // lattice cell means the direction field changes gradually over a broad
    // area instead of independently at every AO pixel.
    float2 p = pixelCoord / 12.0;
    float2 cell = floor(p);
    float2 f = frac(p);

    // Cubic interpolation keeps first derivatives continuous at cell edges.
    f = f * f * (3.0 - 2.0 * f);

    float a = PhaseHash(cell + float2(0.0, 0.0));
    float b = PhaseHash(cell + float2(1.0, 0.0));
    float c = PhaseHash(cell + float2(0.0, 1.0));
    float d = PhaseHash(cell + float2(1.0, 1.0));

    return lerp(
        lerp(a, b, f.x),
        lerp(c, d, f.x),
        f.y);
}

float2 DirectionFromIndex(int i, float phase)
{
    float angle =
        6.28318530718 * ((float)i / (float)SL_AO_DIRECTIONS) + phase;
    return float2(cos(angle), sin(angle));
}

float HorizonDirection(float2 screenUV, float3 centerPos, float3 centerNormal, float2 direction, float radiusPixels)
{
    float horizon = 0.0;
    float radiusWorld = max(AORadius, 1e-4);

    [loop]
    for (int stepIndex = 1; stepIndex <= SL_AO_MAX_STEPS; ++stepIndex)
    {
        if (stepIndex > AOSteps)
            break;

        float t = (float)stepIndex / max((float)AOSteps, 1.0);
        t = lerp(t, t * t, 0.35);

        float2 sampleUV = screenUV + direction * (radiusPixels * t) * ReShade::PixelSize;

        if (sampleUV.x <= 0.0 || sampleUV.x >= 1.0 || sampleUV.y <= 0.0 || sampleUV.y >= 1.0)
            continue;

        // The native samplers are CLAMP. Without this test, samples that leave
        // the 3D viewport but remain inside the application window repeatedly
        // read the G-buffer border and create false occlusion.
        if (!InsideFirestormWorld(sampleUV))
            continue;

        float sampleDepth = GetRawDepth(sampleUV);
        if (IsBackgroundDepth(sampleDepth))
            continue;

        float3 samplePos = ReconstructViewPosition(sampleUV, sampleDepth);
        float3 delta = samplePos - centerPos;
        float dist = length(delta);

        if (dist <= 1e-5 || dist > radiusWorld * 1.35)
            continue;

        float3 dir3 = delta / dist;
        float horizonAngle = dot(centerNormal, dir3);
        float angular = saturate((horizonAngle - AOBias) / max(1.0 - AOBias, 1e-4));
        float normalizedDistance = saturate(dist / radiusWorld);
        float falloff = pow(saturate(1.0 - normalizedDistance), AODistanceFalloff);
        horizon = max(horizon, angular * falloff);
    }

    return horizon;
}

float ComputeAO(float2 screenUV, float2 pixelCoord)
{
    if (!HasBridgeRegistration() || !InsideFirestormWorld(screenUV))
        return 0.0;

    float centerDepth = GetRawDepth(screenUV);
    if (IsBackgroundDepth(centerDepth))
        return 0.0;

    float3 centerPos = ReconstructViewPosition(screenUV, centerDepth);
    float centerDistance = max(-centerPos.z, 1e-4);
    float3 centerNormal = GetFirestormNormal(screenUV);

    float tanHalfFov = max(tan(radians(CameraVerticalFOV) * 0.5), 1e-5);
    float projectionPixels = SLBridgeViewport.w / (2.0 * tanHalfFov);
    float radiusPixels = clamp(AORadius * projectionPixels / centerDistance, 2.0, AOMaxRadiusPixels);

    // Rotate only within one angular sector, and vary that rotation smoothly
    // over a coarse spatial field. This breaks fixed-direction blocks without
    // returning to the old independent per-pixel random rotation.
    float phaseField = SmoothPhase01(pixelCoord) - 0.5;
    float phase =
        phaseField *
        (6.28318530718 / (float)SL_AO_DIRECTIONS) *
        AOPhaseVariation;

    float sum = 0.0;

    [unroll]
    for (int i = 0; i < SL_AO_DIRECTIONS; ++i)
    {
        float2 dir = DirectionFromIndex(i, phase);
        sum += HorizonDirection(screenUV, centerPos, centerNormal, dir, radiusPixels);
    }

    float ao = sum / (float)SL_AO_DIRECTIONS;
    ao = ao * ao * (3.0 - 2.0 * ao);
    return saturate(ao * AOIntensity);
}

float4 BuildRawAOPS(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float ao = ComputeAO(uv, pos.xy);
    return float4(ao, ao, ao, 1.0);
}

float BilateralWeight(float2 centerUV, float2 sampleUV)
{
    if (!InsideFirestormWorld(centerUV) || !InsideFirestormWorld(sampleUV))
        return 0.0;

    float centerRawDepth = GetRawDepth(centerUV);
    float sampleRawDepth = GetRawDepth(sampleUV);

    if (IsBackgroundDepth(centerRawDepth) != IsBackgroundDepth(sampleRawDepth))
        return 0.0;
    if (IsBackgroundDepth(centerRawDepth))
        return 1.0;

    float centerD = LinearViewDistance(centerRawDepth);
    float sampleD = LinearViewDistance(sampleRawDepth);
    float depthDelta = abs(sampleD - centerD);

    float depthScale = max(AORadius, 1e-4);
    float depthWeight = exp2(-BlurDepthSensitivity * depthDelta / depthScale);

    float3 n0 = GetFirestormNormal(centerUV);
    float3 n1 = GetFirestormNormal(sampleUV);
    float normalDifference = 1.0 - saturate(dot(n0, n1));
    float normalWeight = exp2(-BlurNormalSensitivity * normalDifference);

    return depthWeight * normalWeight;
}

float BlurAOFromRaw(float2 uv, float2 axis)
{
    float2 halfResPixel =
        float2(2.0 / (float)BUFFER_WIDTH, 2.0 / (float)BUFFER_HEIGHT);

    float center = tex2D(SLAORawSampler, uv).r;
    float weighted = center * 0.52;
    float weightSum = 0.52;

    [unroll]
    for (int i = 0; i < 2; ++i)
    {
        float offset = (i == 0) ? 1.0 : 2.0;
        float spatial = (i == 0) ? 0.30 : 0.12;

        float2 delta = axis * halfResPixel * offset;
        float2 uvP = uv + delta;
        float2 uvN = uv - delta;

        float wP = spatial * BilateralWeight(uv, uvP);
        float wN = spatial * BilateralWeight(uv, uvN);

        weighted += tex2D(SLAORawSampler, uvP).r * wP;
        weighted += tex2D(SLAORawSampler, uvN).r * wN;
        weightSum += wP + wN;
    }

    float filtered = weighted / max(weightSum, 1e-5);
    return lerp(center, filtered, BlurStrength);
}

float BlurAOFromH(float2 uv, float2 axis)
{
    float2 halfResPixel =
        float2(2.0 / (float)BUFFER_WIDTH, 2.0 / (float)BUFFER_HEIGHT);

    float center = tex2D(SLAOBlurHSampler, uv).r;
    float weighted = center * 0.52;
    float weightSum = 0.52;

    [unroll]
    for (int i = 0; i < 2; ++i)
    {
        float offset = (i == 0) ? 1.0 : 2.0;
        float spatial = (i == 0) ? 0.30 : 0.12;

        float2 delta = axis * halfResPixel * offset;
        float2 uvP = uv + delta;
        float2 uvN = uv - delta;

        float wP = spatial * BilateralWeight(uv, uvP);
        float wN = spatial * BilateralWeight(uv, uvN);

        weighted += tex2D(SLAOBlurHSampler, uvP).r * wP;
        weighted += tex2D(SLAOBlurHSampler, uvN).r * wN;
        weightSum += wP + wN;
    }

    float filtered = weighted / max(weightSum, 1e-5);
    return lerp(center, filtered, BlurStrength);
}

float4 BlurHorizontalPS(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float ao = BlurAOFromRaw(uv, float2(1.0, 0.0));
    return float4(ao, ao, ao, 1.0);
}

float4 BlurVerticalPS(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float ao = BlurAOFromH(uv, float2(0.0, 1.0));
    return float4(ao, ao, ao, 1.0);
}

float UpsampleAO(float2 uv)
{
    // SLAOBlurVTex is half-resolution. Sampling it with LINEAR alone blurs AO
    // across full-resolution depth/normal edges. Reconstruct the 2x2 bilinear
    // footprint manually, then reject neighbors that do not belong to the same
    // Firestorm surface.
    float2 halfSize =
        float2(max((float)BUFFER_WIDTH * 0.5, 1.0),
               max((float)BUFFER_HEIGHT * 0.5, 1.0));

    float2 p = uv * halfSize - 0.5;
    float2 base = floor(p);
    float2 f = frac(p);

    float2 invHalf = 1.0 / halfSize;

    float2 uv00 = (base + float2(0.5, 0.5)) * invHalf;
    float2 uv10 = (base + float2(1.5, 0.5)) * invHalf;
    float2 uv01 = (base + float2(0.5, 1.5)) * invHalf;
    float2 uv11 = (base + float2(1.5, 1.5)) * invHalf;

    float b00 = (1.0 - f.x) * (1.0 - f.y);
    float b10 = f.x * (1.0 - f.y);
    float b01 = (1.0 - f.x) * f.y;
    float b11 = f.x * f.y;

    float w00 = b00 * max(BilateralWeight(uv, uv00), 1e-4);
    float w10 = b10 * max(BilateralWeight(uv, uv10), 1e-4);
    float w01 = b01 * max(BilateralWeight(uv, uv01), 1e-4);
    float w11 = b11 * max(BilateralWeight(uv, uv11), 1e-4);

    float sum =
        tex2D(SLAOBlurVSampler, uv00).r * w00 +
        tex2D(SLAOBlurVSampler, uv10).r * w10 +
        tex2D(SLAOBlurVSampler, uv01).r * w01 +
        tex2D(SLAOBlurVSampler, uv11).r * w11;

    float weight = w00 + w10 + w01 + w11;

    if (weight <= 1e-5)
        return tex2D(SLAOBlurVSampler, uv).r;

    return sum / weight;
}

float3 NormalDebug(float2 uv)
{
    float3 n = GetFirestormNormal(uv);
    return n * 0.5 + 0.5;
}

float3 PositionDebug(float2 uv)
{
    if (!InsideFirestormWorld(uv))
        return float3(0.0, 0.0, 0.0);

    float d = GetRawDepth(uv);
    if (IsBackgroundDepth(d))
        return float3(0.0, 0.0, 0.0);

    float3 p = ReconstructViewPosition(uv, d);
    float scale = max(DebugDepthRange, 1e-3);
    return float3(
        saturate(p.x / scale + 0.5),
        saturate(p.y / scale + 0.5),
        saturate((-p.z) / scale));
}

float3 BridgeAlignmentOverlay(float2 uv)
{
    float3 baseColor = tex2D(ReShade::BackBuffer, uv).rgb;

    if (!InsideFirestormWorld(uv))
        return baseColor;

    float d0 = GetRawDepth(uv);
    float dx = GetRawDepth(uv + float2(ReShade::PixelSize.x, 0.0));
    float dy = GetRawDepth(uv + float2(0.0, ReShade::PixelSize.y));

    float3 n0 = GetFirestormNormal(uv);
    float3 nx = GetFirestormNormal(uv + float2(ReShade::PixelSize.x, 0.0));
    float3 ny = GetFirestormNormal(uv + float2(0.0, ReShade::PixelSize.y));

    float depthEdge = abs(dx - d0) + abs(dy - d0);
    float normalEdge =
        (1.0 - saturate(dot(n0, nx))) +
        (1.0 - saturate(dot(n0, ny)));

    float edge = saturate(depthEdge * 1200.0 + normalEdge * 8.0);
    return lerp(baseColor, float3(1.0, 0.0, 0.0), edge * 0.90);
}

float4 CompositePS(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float ao = UpsampleAO(uv);

    if (DisplayMode == 1)
    {
        float value = 1.0 - ao;
        return float4(value, value, value, 1.0);
    }

    if (DisplayMode == 2)
    {
        float rawAO = tex2D(SLAORawSampler, uv).r;
        float value = 1.0 - rawAO;
        return float4(value, value, value, 1.0);
    }

    if (DisplayMode == 3)
        return float4(NormalDebug(uv), 1.0);

    if (DisplayMode == 4)
    {
        float rawDepth = GetRawDepth(uv);
        float linearD = IsBackgroundDepth(rawDepth) ? DebugDepthRange : LinearViewDistance(rawDepth);
        float value = saturate(linearD / max(DebugDepthRange, 1e-3));
        return float4(value, value, value, 1.0);
    }

    if (DisplayMode == 5)
        return float4(PositionDebug(uv), 1.0);

    if (DisplayMode == 6)
        return float4(BridgeAlignmentOverlay(uv), 1.0);

    float alphaCoverage = GetFirestormAlphaCoverage(uv);

    if (DisplayMode == 7)
        return float4(alphaCoverage, alphaCoverage, alphaCoverage, 1.0);

    float3 color = tex2D(ReShade::BackBuffer, uv).rgb;

    if (!InsideFirestormWorld(uv))
        return float4(color, 1.0);

    // Alpha coverage affects ONLY the final receiver/composite. The AO field,
    // sampling, normals, depth and blur are still exactly the working v0.3 path.
    ao *= (1.0 - saturate(alphaCoverage * AlphaCoverageProtection));
    color *= (1.0 - ao);
    return float4(color, 1.0);
}

technique SL_HBAO_v0_5_Smooth
<
    ui_label = "SL HBAO v0.5 - Smooth Photo AO";
>
{
    pass BuildRawAO
    {
        VertexShader = PostProcessVS;
        PixelShader = BuildRawAOPS;
        RenderTarget = SLAORawTex;
    }

    pass BlurHorizontal
    {
        VertexShader = PostProcessVS;
        PixelShader = BlurHorizontalPS;
        RenderTarget = SLAOBlurHTex;
    }

    pass BlurVertical
    {
        VertexShader = PostProcessVS;
        PixelShader = BlurVerticalPS;
        RenderTarget = SLAOBlurVTex;
    }

    pass Composite
    {
        VertexShader = PostProcessVS;
        PixelShader = CompositePS;
    }
}
