#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#define IMGUI_DISABLE_INCLUDE_IMCONFIG_H

#include <windows.h>
#include <GL/gl.h>

#include <imgui.h>
#include <reshade.hpp>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <mutex>
#include <vector>

namespace api = reshade::api;

namespace
{
    constexpr GLenum GL_CURRENT_PROGRAM_VALUE = 0x8B8D;
    constexpr GLenum GL_TEXTURE_2D_VALUE = 0x0DE1;
    constexpr GLenum GL_TEXTURE_CUBE_MAP_ARRAY_VALUE = 0x9009;
    constexpr GLenum GL_TEXTURE_BINDING_CUBE_MAP_ARRAY_VALUE = 0x900A;
    constexpr GLenum GL_UNIFORM_BUFFER_VALUE = 0x8A11;
    constexpr GLenum GL_UNIFORM_BUFFER_BINDING_VALUE = 0x8A28;
    constexpr GLenum GL_BUFFER_VALUE = 0x82E0;
    constexpr GLenum GL_READ_FRAMEBUFFER_VALUE = 0x8CA8;
    constexpr GLenum GL_DRAW_FRAMEBUFFER_VALUE = 0x8CA9;
    constexpr GLenum GL_READ_FRAMEBUFFER_BINDING_VALUE = 0x8CAA;
    constexpr GLenum GL_DRAW_FRAMEBUFFER_BINDING_VALUE = 0x8CA6;
    constexpr GLenum GL_COLOR_ATTACHMENT0_VALUE = 0x8CE0;
    constexpr GLenum GL_FRAMEBUFFER_COMPLETE_VALUE = 0x8CD5;
    constexpr GLenum GL_FRAMEBUFFER_SRGB_VALUE = 0x8DB9;

    constexpr uint32_t k_irradiance_resolution = 16;
    constexpr uint32_t k_max_probe_count = 256;
    constexpr uint64_t k_reflection_probe_ubo_size = 49248ull;

    // Exact std140 byte offsets for Firestorm ReflectionProbeData.
    // These match LLReflectionMapManager::ReflectionProbeData and
    // class3/deferred/reflectionProbeF.glsl.
    constexpr size_t k_ref_box_offset = 0;
    constexpr size_t k_hero_box_offset = 16384;
    constexpr size_t k_ref_sphere_offset = 16448;
    constexpr size_t k_ref_params_offset = 20544;
    constexpr size_t k_hero_sphere_offset = 24640;
    constexpr size_t k_ref_index_offset = 24656;
    constexpr size_t k_ref_neighbor_offset = 28752;
    constexpr size_t k_ref_bucket_offset = 45136;
    constexpr size_t k_refmap_count_offset = 49232;
    constexpr size_t k_hero_shape_offset = 49236;
    constexpr size_t k_hero_mip_count_offset = 49240;
    constexpr size_t k_hero_probe_count_offset = 49244;

    using pfn_gl_get_uniform_location =
        GLint (APIENTRY *)(GLuint program, const char *name);
    using pfn_gl_get_uniform_iv =
        void (APIENTRY *)(GLuint program, GLint location, GLint *params);
    using pfn_gl_get_integer_i_v =
        void (APIENTRY *)(GLenum target, GLuint index, GLint *data);
    using pfn_gl_bind_buffer =
        void (APIENTRY *)(GLenum target, GLuint buffer);
    using pfn_gl_get_buffer_sub_data =
        void (APIENTRY *)(GLenum target, std::intptr_t offset, std::ptrdiff_t size, void *data);
    using pfn_gl_gen_framebuffers =
        void (APIENTRY *)(GLsizei, GLuint *);
    using pfn_gl_delete_framebuffers =
        void (APIENTRY *)(GLsizei, const GLuint *);
    using pfn_gl_bind_framebuffer =
        void (APIENTRY *)(GLenum, GLuint);
    using pfn_gl_framebuffer_texture_layer =
        void (APIENTRY *)(GLenum, GLenum, GLuint, GLint, GLint);
    using pfn_gl_framebuffer_texture_2d =
        void (APIENTRY *)(GLenum, GLenum, GLenum, GLuint, GLint);
    using pfn_gl_check_framebuffer_status =
        GLenum (APIENTRY *)(GLenum);
    using pfn_gl_read_buffer =
        void (APIENTRY *)(GLenum);
    using pfn_gl_draw_buffer =
        void (APIENTRY *)(GLenum);
    using pfn_gl_blit_framebuffer =
        void (APIENTRY *)(
            GLint, GLint, GLint, GLint,
            GLint, GLint, GLint, GLint,
            GLbitfield, GLenum);

    pfn_gl_get_uniform_location p_glGetUniformLocation = nullptr;
    pfn_gl_get_uniform_iv p_glGetUniformiv = nullptr;
    pfn_gl_get_integer_i_v p_glGetIntegeri_v = nullptr;
    pfn_gl_bind_buffer p_glBindBuffer = nullptr;
    pfn_gl_get_buffer_sub_data p_glGetBufferSubData = nullptr;
    pfn_gl_gen_framebuffers p_glGenFramebuffers = nullptr;
    pfn_gl_delete_framebuffers p_glDeleteFramebuffers = nullptr;
    pfn_gl_bind_framebuffer p_glBindFramebuffer = nullptr;
    pfn_gl_framebuffer_texture_layer p_glFramebufferTextureLayer = nullptr;
    pfn_gl_framebuffer_texture_2d p_glFramebufferTexture2D = nullptr;
    pfn_gl_check_framebuffer_status p_glCheckFramebufferStatus = nullptr;
    pfn_gl_read_buffer p_glReadBuffer = nullptr;
    pfn_gl_draw_buffer p_glDrawBuffer = nullptr;
    pfn_gl_blit_framebuffer p_glBlitFramebuffer = nullptr;

    template <typename T>
    T load_gl_proc(const char *name)
    {
        PROC proc = wglGetProcAddress(name);

        if (proc == nullptr ||
            proc == reinterpret_cast<PROC>(1) ||
            proc == reinterpret_cast<PROC>(2) ||
            proc == reinterpret_cast<PROC>(3) ||
            proc == reinterpret_cast<PROC>(-1))
        {
            HMODULE module = GetModuleHandleW(L"opengl32.dll");
            if (module == nullptr)
                module = LoadLibraryW(L"opengl32.dll");

            if (module != nullptr)
                proc = GetProcAddress(module, name);
        }

        return reinterpret_cast<T>(proc);
    }

    bool load_gl_functions()
    {
        if (p_glGetUniformLocation != nullptr &&
            p_glGetUniformiv != nullptr &&
            p_glGetIntegeri_v != nullptr &&
            p_glBindBuffer != nullptr &&
            p_glGetBufferSubData != nullptr &&
            p_glGenFramebuffers != nullptr &&
            p_glDeleteFramebuffers != nullptr &&
            p_glBindFramebuffer != nullptr &&
            p_glFramebufferTextureLayer != nullptr &&
            p_glFramebufferTexture2D != nullptr &&
            p_glCheckFramebufferStatus != nullptr &&
            p_glReadBuffer != nullptr &&
            p_glDrawBuffer != nullptr &&
            p_glBlitFramebuffer != nullptr)
            return true;

        p_glGetUniformLocation =
            load_gl_proc<pfn_gl_get_uniform_location>("glGetUniformLocation");
        p_glGetUniformiv =
            load_gl_proc<pfn_gl_get_uniform_iv>("glGetUniformiv");
        p_glGetIntegeri_v =
            load_gl_proc<pfn_gl_get_integer_i_v>("glGetIntegeri_v");
        p_glBindBuffer =
            load_gl_proc<pfn_gl_bind_buffer>("glBindBuffer");
        p_glGetBufferSubData =
            load_gl_proc<pfn_gl_get_buffer_sub_data>("glGetBufferSubData");
        p_glGenFramebuffers =
            load_gl_proc<pfn_gl_gen_framebuffers>("glGenFramebuffers");
        p_glDeleteFramebuffers =
            load_gl_proc<pfn_gl_delete_framebuffers>("glDeleteFramebuffers");
        p_glBindFramebuffer =
            load_gl_proc<pfn_gl_bind_framebuffer>("glBindFramebuffer");
        p_glFramebufferTextureLayer =
            load_gl_proc<pfn_gl_framebuffer_texture_layer>("glFramebufferTextureLayer");
        p_glFramebufferTexture2D =
            load_gl_proc<pfn_gl_framebuffer_texture_2d>("glFramebufferTexture2D");
        p_glCheckFramebufferStatus =
            load_gl_proc<pfn_gl_check_framebuffer_status>("glCheckFramebufferStatus");
        p_glReadBuffer =
            load_gl_proc<pfn_gl_read_buffer>("glReadBuffer");
        p_glDrawBuffer =
            load_gl_proc<pfn_gl_draw_buffer>("glDrawBuffer");
        p_glBlitFramebuffer =
            load_gl_proc<pfn_gl_blit_framebuffer>("glBlitFramebuffer");

        return p_glGetUniformLocation != nullptr &&
               p_glGetUniformiv != nullptr &&
               p_glGetIntegeri_v != nullptr &&
               p_glBindBuffer != nullptr &&
               p_glGetBufferSubData != nullptr &&
               p_glGenFramebuffers != nullptr &&
               p_glDeleteFramebuffers != nullptr &&
               p_glBindFramebuffer != nullptr &&
               p_glFramebufferTextureLayer != nullptr &&
               p_glFramebufferTexture2D != nullptr &&
               p_glCheckFramebufferStatus != nullptr &&
               p_glReadBuffer != nullptr &&
               p_glDrawBuffer != nullptr &&
               p_glBlitFramebuffer != nullptr;
    }

    api::resource make_gl_resource(GLenum target, GLuint object)
    {
        if (object == 0)
            return { 0 };

        return
        {
            (static_cast<uint64_t>(target) << 40) |
            static_cast<uint64_t>(object)
        };
    }

    uint32_t gl_object_id(api::resource resource)
    {
        return static_cast<uint32_t>(resource.handle & 0xFFFFFFFFull);
    }

    bool has_flag(api::resource_flags value, api::resource_flags flag)
    {
        return (value & flag) != api::resource_flags::none;
    }

    bool is_cube_array_resource(const api::resource_desc &desc)
    {
        return desc.type == api::resource_type::texture_2d &&
               has_flag(desc.flags, api::resource_flags::cube_compatible) &&
               desc.texture.depth_or_layers >= 6 &&
               (desc.texture.depth_or_layers % 6) == 0;
    }

    uint32_t cube_count(const api::resource_desc &desc)
    {
        return is_cube_array_resource(desc)
            ? static_cast<uint32_t>(desc.texture.depth_or_layers / 6)
            : 0;
    }

    bool is_irradiance_shape(const api::resource_desc &desc)
    {
        if (!is_cube_array_resource(desc))
            return false;

        const uint32_t probes = cube_count(desc);
        return desc.texture.width == k_irradiance_resolution &&
               desc.texture.height == k_irradiance_resolution &&
               desc.texture.levels == 1 &&
               probes >= 1 && probes <= k_max_probe_count;
    }

    bool is_radiance_shape(const api::resource_desc &desc)
    {
        if (!is_cube_array_resource(desc))
            return false;

        const uint32_t cubes = cube_count(desc);
        return desc.texture.width >= 64 &&
               desc.texture.height == desc.texture.width &&
               desc.texture.levels > 1 &&
               cubes >= 3 && cubes <= (k_max_probe_count + 2);
    }

    struct sampler_capture
    {
        bool uniform_present = false;
        bool texture_bound = false;
        bool desc_valid = false;
        bool expected_shape = false;

        GLuint program = 0;
        GLint unit = -1;
        GLuint texture = 0;
        api::resource resource = { 0 };
        api::resource_desc desc = {};
    };

    struct ubo_capture
    {
        bool found = false;
        bool exact_size = false;

        GLuint gl_buffer = 0;
        api::resource resource = { 0 };
        api::resource_desc desc = {};
        uint64_t effective_size = 0;
    };

    struct paired_capture
    {
        bool found = false;
        bool same_draw_valid = false;
        bool ubo_exact = false;
        int score = -1;

        GLuint program = 0;
        sampler_capture irradiance = {};
        sampler_capture radiance = {};
        ubo_capture ubo = {};
    };

    struct frame_capture
    {
        bool gl_functions_ready = false;
        uint64_t draws_examined = 0;
        uint64_t draws_with_irradiance_uniform = 0;
        uint64_t draws_with_radiance_uniform = 0;
        uint64_t draws_with_both_uniforms = 0;
        uint64_t structurally_consistent_pairs = 0;

        paired_capture best_pair = {};

        void clear_per_frame_counts()
        {
            draws_examined = 0;
            draws_with_irradiance_uniform = 0;
            draws_with_radiance_uniform = 0;
            draws_with_both_uniforms = 0;
            structurally_consistent_pairs = 0;

            // Preserve the last identity as a quiet-frame fallback, but lower
            // its score so any observed pair this frame replaces it.
            best_pair.score = -1;
        }
    };

    struct snapshot_state
    {
        uint64_t frame_index = 0;
        frame_capture capture = {};
    };

    struct metadata_snapshot
    {
        bool readback_ok = false;
        bool count_valid = false;

        int32_t refmap_count = 0;
        int32_t hero_shape = 0;
        int32_t hero_mip_count = 0;
        int32_t hero_probe_count = 0;

        float first_sphere[4] = {};
        float first_params[4] = {};
        int32_t first_index[4] = {};

        uint64_t readback_count = 0;
    };

    struct private_atlas
    {
        api::resource resource = { 0 };
        api::resource_view view = { 0 };
        api::resource_desc desc = {};

        uint32_t face_size = 0;
        uint32_t cube_count = 0;

        bool semantic_bound = false;
        bool state_is_shader_resource = false;
        bool ready = false;
        bool copy_valid_last_effects = false;
        bool fbo_complete_last_effects = false;

        GLuint read_fbo = 0;
        GLuint draw_fbo = 0;

        uint64_t recreate_count = 0;
        uint64_t copy_count = 0;
        GLenum last_gl_error = GL_NO_ERROR;
    };

    struct __declspec(uuid("C67F9F3A-E5D3-46E9-9A8C-58F2B3B38D9C")) device_data
    {
        std::mutex mutex;
        frame_capture current;
        snapshot_state last;
        metadata_snapshot metadata;
    };

    struct __declspec(uuid("36B7B86A-1C2D-43B4-8443-E0D8D2B51A12")) runtime_data
    {
        private_atlas atlas;
    };

    std::atomic_bool g_inside_reshade_effects { false };
    std::atomic_bool g_opengl_seen { false };

    bool read_sampler_unit(GLuint program, const char *name, GLint &unit)
    {
        const GLint location = p_glGetUniformLocation(program, name);
        if (location < 0)
            return false;

        p_glGetUniformiv(program, location, &unit);
        return unit >= 0;
    }

    sampler_capture inspect_cube_sampler(
        api::device *device,
        GLuint program,
        const char *uniform_name,
        bool expect_irradiance)
    {
        sampler_capture result = {};
        result.program = program;

        GLint unit = -1;
        if (!read_sampler_unit(program, uniform_name, unit))
            return result;

        result.uniform_present = true;
        result.unit = unit;

        GLint texture = 0;
        p_glGetIntegeri_v(
            GL_TEXTURE_BINDING_CUBE_MAP_ARRAY_VALUE,
            static_cast<GLuint>(unit),
            &texture);

        if (texture <= 0)
            return result;

        result.texture_bound = true;
        result.texture = static_cast<GLuint>(texture);
        result.resource = make_gl_resource(
            GL_TEXTURE_CUBE_MAP_ARRAY_VALUE,
            result.texture);

        result.desc = device->get_resource_desc(result.resource);
        if (result.desc.type == api::resource_type::unknown)
            return result;

        result.desc_valid = true;
        result.expected_shape = expect_irradiance
            ? is_irradiance_shape(result.desc)
            : is_radiance_shape(result.desc);

        return result;
    }

    ubo_capture inspect_bound_probe_ubo(api::device *device)
    {
        ubo_capture result = {};

        GLint raw_ubo_id = 0;
        p_glGetIntegeri_v(
            GL_UNIFORM_BUFFER_BINDING_VALUE,
            0,
            &raw_ubo_id);

        if (raw_ubo_id <= 0)
            return result;

        result.gl_buffer = static_cast<GLuint>(raw_ubo_id);
        result.resource = make_gl_resource(
            GL_BUFFER_VALUE,
            result.gl_buffer);
        result.desc = device->get_resource_desc(result.resource);

        if (result.desc.type != api::resource_type::buffer)
            return result;

        result.found = true;
        result.effective_size = result.desc.buffer.size;
        result.exact_size =
            result.effective_size == k_reflection_probe_ubo_size;

        return result;
    }

    int pair_score(
        const sampler_capture &irr,
        const sampler_capture &rad,
        const ubo_capture &ubo,
        bool same_draw_valid)
    {
        int score = 0;
        if (irr.uniform_present && rad.uniform_present)
            score += 1;
        if (irr.texture_bound && rad.texture_bound)
            score += 2;
        if (irr.expected_shape)
            score += 8;
        if (rad.expected_shape)
            score += 4;
        if (ubo.exact_size)
            score += 16;
        if (same_draw_valid)
            score += 32;
        return score;
    }

    void capture_raw_probe_bindings(api::command_list *cmd_list)
    {
        if (g_inside_reshade_effects.load(std::memory_order_relaxed))
            return;

        api::device *const device = cmd_list->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        device_data *const data = device->get_private_data<device_data>();
        if (data == nullptr)
            return;

        if (!load_gl_functions())
            return;

        GLint current_program = 0;
        glGetIntegerv(GL_CURRENT_PROGRAM_VALUE, &current_program);
        if (current_program <= 0)
            return;

        const GLuint program = static_cast<GLuint>(current_program);

        sampler_capture irradiance = inspect_cube_sampler(
            device,
            program,
            "irradianceProbes",
            true);

        sampler_capture radiance = inspect_cube_sampler(
            device,
            program,
            "reflectionProbes",
            false);

        ubo_capture ubo = {};
        if (irradiance.uniform_present || radiance.uniform_present)
            ubo = inspect_bound_probe_ubo(device);

        std::lock_guard<std::mutex> lock(data->mutex);
        data->current.gl_functions_ready = true;
        data->current.draws_examined++;

        if (irradiance.uniform_present)
            data->current.draws_with_irradiance_uniform++;

        if (radiance.uniform_present)
            data->current.draws_with_radiance_uniform++;

        if (!(irradiance.uniform_present && radiance.uniform_present))
            return;

        data->current.draws_with_both_uniforms++;

        // v0.3 incorrectly required:
        //     reflection cube count == irradiance cube count + 2
        //
        // The live Firestorm runtime disproved that assumption: the SAME draw
        // can legitimately bind a 16x16 irradiance cube array and a larger
        // reflection/radiance cube array with a different capacity.
        //
        // The authoritative identifiers are instead:
        //   * both exact Firestorm sampler names are present on the SAME draw
        //   * irradianceProbes is a valid 16x16 single-mip cube-array
        //   * reflectionProbes is a valid radiance-shaped cube-array
        //   * binding-0 UBO is the exact 49,248-byte ReflectionProbeData
        const bool same_draw_valid =
            irradiance.expected_shape &&
            radiance.expected_shape &&
            ubo.exact_size;

        if (same_draw_valid)
            data->current.structurally_consistent_pairs++;

        paired_capture candidate = {};
        candidate.found = true;
        candidate.same_draw_valid = same_draw_valid;
        candidate.ubo_exact = ubo.exact_size;
        candidate.program = program;
        candidate.irradiance = irradiance;
        candidate.radiance = radiance;
        candidate.ubo = ubo;
        candidate.score = pair_score(
            irradiance,
            radiance,
            ubo,
            same_draw_valid);

        if (candidate.score >= data->current.best_pair.score)
            data->current.best_pair = candidate;
    }

    bool on_draw(
        api::command_list *cmd_list,
        uint32_t,
        uint32_t,
        uint32_t,
        uint32_t)
    {
        capture_raw_probe_bindings(cmd_list);
        return false;
    }

    bool on_draw_indexed(
        api::command_list *cmd_list,
        uint32_t,
        uint32_t,
        uint32_t,
        int32_t,
        uint32_t)
    {
        capture_raw_probe_bindings(cmd_list);
        return false;
    }

    void set_all_float_uniforms_named(
        api::effect_runtime *runtime,
        const char *uniform_name,
        const float *values,
        size_t count)
    {
        runtime->enumerate_uniform_variables(
            nullptr,
            [&](api::effect_runtime *rt,
                api::effect_uniform_variable variable)
            {
                char name[128] = {};
                rt->get_uniform_variable_name(variable, name);

                if (std::strcmp(name, uniform_name) == 0)
                {
                    rt->set_uniform_value_float(
                        variable,
                        values,
                        count);
                }
            });
    }

    void unbind_atlas(api::effect_runtime *runtime, private_atlas *atlas)
    {
        runtime->update_texture_bindings(
            "SL_IRRADIANCE_ATLAS",
            api::resource_view { 0 },
            api::resource_view { 0 });

        if (atlas != nullptr)
        {
            atlas->semantic_bound = false;
            atlas->copy_valid_last_effects = false;
        }
    }

    void destroy_atlas(api::effect_runtime *runtime, private_atlas *atlas)
    {
        if (atlas == nullptr)
            return;

        unbind_atlas(runtime, atlas);

        api::device *const device = runtime->get_device();

        if (atlas->read_fbo != 0 && p_glDeleteFramebuffers != nullptr)
        {
            p_glDeleteFramebuffers(1, &atlas->read_fbo);
            atlas->read_fbo = 0;
        }

        if (atlas->draw_fbo != 0 && p_glDeleteFramebuffers != nullptr)
        {
            p_glDeleteFramebuffers(1, &atlas->draw_fbo);
            atlas->draw_fbo = 0;
        }

        if (atlas->view != 0)
        {
            device->destroy_resource_view(atlas->view);
            atlas->view = { 0 };
        }

        if (atlas->resource != 0)
        {
            device->destroy_resource(atlas->resource);
            atlas->resource = { 0 };
        }

        atlas->desc = {};
        atlas->face_size = 0;
        atlas->cube_count = 0;
        atlas->state_is_shader_resource = false;
        atlas->ready = false;
        atlas->fbo_complete_last_effects = false;
        atlas->last_gl_error = GL_NO_ERROR;
    }

    bool same_atlas_shape(
        const private_atlas &atlas,
        uint32_t width,
        uint32_t height,
        api::format format)
    {
        return atlas.resource != 0 &&
               atlas.desc.texture.width == width &&
               atlas.desc.texture.height == height &&
               atlas.desc.texture.format == format;
    }

    bool ensure_atlas(
        api::effect_runtime *runtime,
        private_atlas *atlas,
        const api::resource_desc &source_desc)
    {
        if (atlas == nullptr)
            return false;

        const uint32_t faces = source_desc.texture.depth_or_layers;
        if (faces < 6 || (faces % 6) != 0)
            return false;

        const uint32_t cubes = faces / 6;
        const uint32_t face_size = source_desc.texture.width;
        const uint32_t atlas_width = face_size * 6;
        const uint32_t atlas_height = face_size * cubes;

        if (same_atlas_shape(
                *atlas,
                atlas_width,
                atlas_height,
                source_desc.texture.format))
        {
            atlas->face_size = face_size;
            atlas->cube_count = cubes;
            return true;
        }

        if (atlas->resource != 0 || atlas->view != 0)
        {
            runtime->get_command_queue()->wait_idle();
            destroy_atlas(runtime, atlas);
        }

        api::resource_desc desc(
            atlas_width,
            atlas_height,
            1,
            1,
            source_desc.texture.format,
            1,
            api::memory_heap::default_,
            api::resource_usage::render_target |
            api::resource_usage::shader_resource);

        api::resource resource = { 0 };
        if (!runtime->get_device()->create_resource(
                desc,
                nullptr,
                api::resource_usage::render_target,
                &resource))
        {
            reshade::log::message(
                reshade::log::level::error,
                "SLProbeBridge v0.3ba: failed to create private irradiance atlas resource.");
            return false;
        }

        api::resource_view view = { 0 };
        api::resource_view_desc view_desc(desc.texture.format);

        if (!runtime->get_device()->create_resource_view(
                resource,
                api::resource_usage::shader_resource,
                view_desc,
                &view))
        {
            runtime->get_device()->destroy_resource(resource);
            reshade::log::message(
                reshade::log::level::error,
                "SLProbeBridge v0.3ba: failed to create private irradiance atlas view.");
            return false;
        }

        runtime->get_device()->set_resource_name(
            resource,
            "SL Probe Bridge private Firestorm irradiance atlas");
        runtime->get_device()->set_resource_view_name(
            view,
            "SL_IRRADIANCE_ATLAS private view");

        atlas->resource = resource;
        atlas->view = view;
        atlas->desc = desc;
        atlas->face_size = face_size;
        atlas->cube_count = cubes;
        atlas->state_is_shader_resource = false;
        atlas->ready = true;
        atlas->recreate_count++;

        if (atlas->read_fbo == 0)
            p_glGenFramebuffers(1, &atlas->read_fbo);

        if (atlas->draw_fbo == 0)
            p_glGenFramebuffers(1, &atlas->draw_fbo);

        if (atlas->read_fbo == 0 || atlas->draw_fbo == 0)
            return false;

        return true;
    }

    bool copy_irradiance_to_atlas(
        api::effect_runtime *runtime,
        api::command_list *cmd_list,
        private_atlas *atlas,
        const sampler_capture &irradiance)
    {
        if (atlas == nullptr ||
            !irradiance.texture_bound ||
            !irradiance.desc_valid ||
            !irradiance.expected_shape)
            return false;

        if (!ensure_atlas(runtime, atlas, irradiance.desc))
            return false;

        if (atlas->state_is_shader_resource)
        {
            cmd_list->barrier(
                atlas->resource,
                api::resource_usage::shader_resource,
                api::resource_usage::render_target);
        }

        GLint previous_read_fbo = 0;
        GLint previous_draw_fbo = 0;

        glGetIntegerv(
            GL_READ_FRAMEBUFFER_BINDING_VALUE,
            &previous_read_fbo);
        glGetIntegerv(
            GL_DRAW_FRAMEBUFFER_BINDING_VALUE,
            &previous_draw_fbo);

        const GLboolean scissor_was_enabled =
            glIsEnabled(GL_SCISSOR_TEST);
        const GLboolean framebuffer_srgb_was_enabled =
            glIsEnabled(GL_FRAMEBUFFER_SRGB_VALUE);

        if (scissor_was_enabled)
            glDisable(GL_SCISSOR_TEST);
        if (framebuffer_srgb_was_enabled)
            glDisable(GL_FRAMEBUFFER_SRGB_VALUE);

        while (glGetError() != GL_NO_ERROR) {}

        p_glBindFramebuffer(
            GL_READ_FRAMEBUFFER_VALUE,
            atlas->read_fbo);
        p_glBindFramebuffer(
            GL_DRAW_FRAMEBUFFER_VALUE,
            atlas->draw_fbo);

        const GLuint dst_texture =
            gl_object_id(atlas->resource);

        p_glFramebufferTexture2D(
            GL_DRAW_FRAMEBUFFER_VALUE,
            GL_COLOR_ATTACHMENT0_VALUE,
            GL_TEXTURE_2D_VALUE,
            dst_texture,
            0);
        p_glDrawBuffer(
            GL_COLOR_ATTACHMENT0_VALUE);

        bool framebuffer_complete =
            p_glCheckFramebufferStatus(
                GL_DRAW_FRAMEBUFFER_VALUE) ==
            GL_FRAMEBUFFER_COMPLETE_VALUE;

        const uint32_t face_size =
            atlas->face_size;

        for (uint32_t cube = 0;
             framebuffer_complete && cube < atlas->cube_count;
             ++cube)
        {
            for (uint32_t face = 0;
                 framebuffer_complete && face < 6;
                 ++face)
            {
                const GLint source_layer =
                    static_cast<GLint>(
                        cube * 6 + face);

                p_glFramebufferTextureLayer(
                    GL_READ_FRAMEBUFFER_VALUE,
                    GL_COLOR_ATTACHMENT0_VALUE,
                    irradiance.texture,
                    0,
                    source_layer);
                p_glReadBuffer(
                    GL_COLOR_ATTACHMENT0_VALUE);

                framebuffer_complete =
                    p_glCheckFramebufferStatus(
                        GL_READ_FRAMEBUFFER_VALUE) ==
                    GL_FRAMEBUFFER_COMPLETE_VALUE;

                if (!framebuffer_complete)
                    break;

                const GLint dst_x0 =
                    static_cast<GLint>(
                        face * face_size);
                const GLint dst_y0 =
                    static_cast<GLint>(
                        cube * face_size);
                const GLint dst_x1 =
                    dst_x0 +
                    static_cast<GLint>(face_size);
                const GLint dst_y1 =
                    dst_y0 +
                    static_cast<GLint>(face_size);

                p_glBlitFramebuffer(
                    0, 0,
                    static_cast<GLint>(face_size),
                    static_cast<GLint>(face_size),
                    dst_x0, dst_y0,
                    dst_x1, dst_y1,
                    GL_COLOR_BUFFER_BIT,
                    GL_NEAREST);
            }
        }

        atlas->last_gl_error =
            glGetError();
        atlas->fbo_complete_last_effects =
            framebuffer_complete;

        p_glBindFramebuffer(
            GL_READ_FRAMEBUFFER_VALUE,
            previous_read_fbo > 0
                ? static_cast<GLuint>(previous_read_fbo)
                : 0);
        p_glBindFramebuffer(
            GL_DRAW_FRAMEBUFFER_VALUE,
            previous_draw_fbo > 0
                ? static_cast<GLuint>(previous_draw_fbo)
                : 0);

        if (scissor_was_enabled)
            glEnable(GL_SCISSOR_TEST);
        if (framebuffer_srgb_was_enabled)
            glEnable(GL_FRAMEBUFFER_SRGB_VALUE);

        cmd_list->barrier(
            atlas->resource,
            api::resource_usage::render_target,
            api::resource_usage::shader_resource);

        atlas->state_is_shader_resource = true;

        if (!framebuffer_complete ||
            atlas->last_gl_error != GL_NO_ERROR)
        {
            atlas->copy_valid_last_effects = false;
            unbind_atlas(runtime, atlas);
            return false;
        }

        runtime->update_texture_bindings(
            "SL_IRRADIANCE_ATLAS",
            atlas->view,
            atlas->view);

        atlas->semantic_bound = true;
        atlas->copy_valid_last_effects = true;
        atlas->copy_count++;
        return true;
    }

    bool read_probe_metadata(
        GLuint ubo,
        metadata_snapshot &out)
    {
        out.readback_ok = false;
        out.count_valid = false;

        if (ubo == 0 ||
            p_glBindBuffer == nullptr ||
            p_glGetBufferSubData == nullptr)
            return false;

        std::vector<uint8_t> bytes(
            static_cast<size_t>(k_reflection_probe_ubo_size));

        GLint previous = 0;
        glGetIntegerv(
            GL_UNIFORM_BUFFER_BINDING_VALUE,
            &previous);

        p_glBindBuffer(
            GL_UNIFORM_BUFFER_VALUE,
            ubo);

        p_glGetBufferSubData(
            GL_UNIFORM_BUFFER_VALUE,
            0,
            static_cast<std::ptrdiff_t>(bytes.size()),
            bytes.data());

        const GLenum error = glGetError();

        p_glBindBuffer(
            GL_UNIFORM_BUFFER_VALUE,
            previous > 0 ? static_cast<GLuint>(previous) : 0);

        if (error != GL_NO_ERROR)
            return false;

        auto copy_bytes = [&](size_t offset, void *dst, size_t size)
        {
            if (offset + size <= bytes.size())
                std::memcpy(dst, bytes.data() + offset, size);
        };

        copy_bytes(
            k_refmap_count_offset,
            &out.refmap_count,
            sizeof(out.refmap_count));
        copy_bytes(
            k_hero_shape_offset,
            &out.hero_shape,
            sizeof(out.hero_shape));
        copy_bytes(
            k_hero_mip_count_offset,
            &out.hero_mip_count,
            sizeof(out.hero_mip_count));
        copy_bytes(
            k_hero_probe_count_offset,
            &out.hero_probe_count,
            sizeof(out.hero_probe_count));

        copy_bytes(
            k_ref_sphere_offset,
            out.first_sphere,
            sizeof(out.first_sphere));
        copy_bytes(
            k_ref_params_offset,
            out.first_params,
            sizeof(out.first_params));
        copy_bytes(
            k_ref_index_offset,
            out.first_index,
            sizeof(out.first_index));

        out.readback_ok = true;
        out.count_valid =
            out.refmap_count >= 0 &&
            out.refmap_count <= static_cast<int32_t>(k_max_probe_count);
        out.readback_count++;

        return true;
    }

    void on_init_device(api::device *device)
    {
        device->create_private_data<device_data>();

        if (device->get_api() == api::device_api::opengl)
        {
            g_opengl_seen.store(true, std::memory_order_relaxed);
            reshade::log::message(
                reshade::log::level::info,
                "SLProbeBridge v0.3ba: OpenGL detected. Paired probe capture + private atlas enabled.");
        }
    }

    void on_destroy_device(api::device *device)
    {
        device->destroy_private_data<device_data>();
    }

    void on_init_effect_runtime(api::effect_runtime *runtime)
    {
        runtime->create_private_data<runtime_data>();
    }

    void on_destroy_effect_runtime(api::effect_runtime *runtime)
    {
        runtime_data *const state =
            runtime->get_private_data<runtime_data>();

        if (state != nullptr)
        {
            destroy_atlas(
                runtime,
                &state->atlas);

            runtime->destroy_private_data<runtime_data>();
        }
    }

    void on_present(
        api::command_queue *,
        api::swapchain *swapchain,
        const api::rect *,
        const api::rect *,
        uint32_t,
        const api::rect *)
    {
        api::device *const device = swapchain->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        device_data *const data = device->get_private_data<device_data>();
        if (data == nullptr)
            return;

        std::lock_guard<std::mutex> lock(data->mutex);

        data->last.frame_index++;
        data->last.capture = data->current;
        data->current.clear_per_frame_counts();
    }

    void on_begin_effects(
        api::effect_runtime *runtime,
        api::command_list *cmd_list,
        api::resource_view,
        api::resource_view)
    {
        g_inside_reshade_effects.store(true, std::memory_order_relaxed);

        if (runtime == nullptr || cmd_list == nullptr)
            return;

        api::device *const device = runtime->get_device();
        if (device == nullptr || device->get_api() != api::device_api::opengl)
            return;

        device_data *const device_state =
            device->get_private_data<device_data>();
        runtime_data *const runtime_state =
            runtime->get_private_data<runtime_data>();

        if (device_state == nullptr || runtime_state == nullptr)
            return;

        paired_capture pair = {};
        {
            std::lock_guard<std::mutex> lock(device_state->mutex);
            pair = device_state->last.capture.best_pair;
        }

        bool atlas_valid = false;
        metadata_snapshot metadata = {};

        if (pair.found &&
            pair.same_draw_valid &&
            pair.ubo_exact &&
            pair.irradiance.expected_shape)
        {
            atlas_valid =
                copy_irradiance_to_atlas(
                    runtime,
                    cmd_list,
                    &runtime_state->atlas,
                    pair.irradiance);

            metadata = device_state->metadata;
            if (read_probe_metadata(
                    pair.ubo.gl_buffer,
                    metadata))
            {
                std::lock_guard<std::mutex> lock(device_state->mutex);
                device_state->metadata = metadata;
            }
        }
        else
        {
            unbind_atlas(
                runtime,
                &runtime_state->atlas);
        }

        const float bridge_valid =
            atlas_valid &&
            metadata.readback_ok &&
            metadata.count_valid
                ? 1.0f
                : 0.0f;

        const float atlas_info[4] =
        {
            static_cast<float>(runtime_state->atlas.desc.texture.width),
            static_cast<float>(runtime_state->atlas.desc.texture.height),
            static_cast<float>(runtime_state->atlas.cube_count),
            static_cast<float>(runtime_state->atlas.face_size)
        };

        const float refmap_count =
            static_cast<float>(metadata.refmap_count);

        set_all_float_uniforms_named(
            runtime,
            "SLProbeBridgeValid",
            &bridge_valid,
            1);
        set_all_float_uniforms_named(
            runtime,
            "SLProbeAtlasInfo",
            atlas_info,
            4);
        set_all_float_uniforms_named(
            runtime,
            "SLProbeRefMapCount",
            &refmap_count,
            1);
    }

    void on_finish_effects(
        api::effect_runtime *,
        api::command_list *,
        api::resource_view,
        api::resource_view)
    {
        g_inside_reshade_effects.store(false, std::memory_order_relaxed);
    }

    void draw_sampler(
        const char *title,
        const sampler_capture &c)
    {
        ImGui::TextUnformatted(title);
        ImGui::Indent();

        ImGui::Text("Uniform present: %s",
            c.uniform_present ? "YES" : "no");
        ImGui::Text("Texture bound: %s",
            c.texture_bound ? "YES" : "no");

        if (c.uniform_present)
        {
            ImGui::Text("Program: %u", c.program);
            ImGui::Text("Sampler unit: %d", c.unit);
        }

        if (c.texture_bound)
            ImGui::Text("GL texture object: %u", c.texture);

        if (c.desc_valid)
        {
            ImGui::Text(
                "Size: %u x %u",
                c.desc.texture.width,
                c.desc.texture.height);
            ImGui::Text(
                "Layers: %u  (cube count: %u)",
                c.desc.texture.depth_or_layers,
                cube_count(c.desc));
            ImGui::Text(
                "Mip levels: %u",
                c.desc.texture.levels);
            ImGui::Text(
                "Format enum: %u",
                static_cast<uint32_t>(c.desc.texture.format));
            ImGui::Text(
                "Expected Firestorm shape: %s",
                c.expected_shape ? "YES" : "no");
        }

        ImGui::Unindent();
    }

    void draw_overlay(api::effect_runtime *runtime)
    {
        if (runtime == nullptr)
            return;

        api::device *const device = runtime->get_device();
        if (device == nullptr)
            return;

        device_data *const device_state =
            device->get_private_data<device_data>();
        runtime_data *const runtime_state =
            runtime->get_private_data<runtime_data>();

        if (device_state == nullptr || runtime_state == nullptr)
            return;

        snapshot_state snapshot = {};
        metadata_snapshot metadata = {};
        {
            std::lock_guard<std::mutex> lock(device_state->mutex);
            snapshot = device_state->last;
            metadata = device_state->metadata;
        }

        const frame_capture &c = snapshot.capture;
        const paired_capture &pair = c.best_pair;
        const private_atlas &atlas = runtime_state->atlas;

        ImGui::TextUnformatted("SL Probe Bridge v0.3b - FBO-copied Firestorm irradiance atlas");
        ImGui::Separator();

        ImGui::Text(
            "Renderer: %s",
            g_opengl_seen.load(std::memory_order_relaxed)
                ? "OpenGL detected"
                : "not OpenGL / not observed");
        ImGui::Text(
            "Raw GL copy/readback functions: %s",
            c.gl_functions_ready ? "READY" : "not ready");
        ImGui::Text(
            "Observed frame: %llu",
            static_cast<unsigned long long>(snapshot.frame_index));
        ImGui::Text(
            "Draws examined: %llu",
            static_cast<unsigned long long>(c.draws_examined));
        ImGui::Text(
            "Draws with both probe samplers: %llu",
            static_cast<unsigned long long>(c.draws_with_both_uniforms));
        ImGui::Text(
            "Validated same-draw Firestorm probe bindings: %llu",
            static_cast<unsigned long long>(c.structurally_consistent_pairs));

        ImGui::Separator();
        ImGui::TextUnformatted("Best same-draw Firestorm probe pair:");
        ImGui::Indent();
        ImGui::Text("Found: %s", pair.found ? "YES" : "no");
        if (pair.found)
        {
            ImGui::Text("Program: %u", pair.program);
            ImGui::Text(
                "Same-draw Firestorm sampler signature: %s",
                pair.same_draw_valid ? "YES" : "no");
            ImGui::Text(
                "Exact 49,248-byte UBO on same draw: %s",
                pair.ubo_exact ? "YES" : "no");
            ImGui::Text(
                "Irradiance shape accepted independently of radiance capacity: %s",
                pair.irradiance.expected_shape ? "YES" : "no");
            ImGui::Text(
                "UBO object: %u",
                pair.ubo.gl_buffer);
        }
        ImGui::Unindent();

        if (pair.found)
        {
            ImGui::Spacing();
            draw_sampler(
                "Paired irradianceProbes:",
                pair.irradiance);
            ImGui::Spacing();
            draw_sampler(
                "Paired reflectionProbes:",
                pair.radiance);
        }

        ImGui::Separator();
        ImGui::TextUnformatted("Private irradiance atlas:");
        ImGui::Indent();
        ImGui::Text("Created: %s", atlas.ready ? "YES" : "no");
        if (atlas.ready)
        {
            ImGui::Text(
                "Atlas size: %u x %u",
                atlas.desc.texture.width,
                atlas.desc.texture.height);
            ImGui::Text(
                "Face size / cubes: %u / %u",
                atlas.face_size,
                atlas.cube_count);
            ImGui::Text(
                "Semantic SL_IRRADIANCE_ATLAS bound: %s",
                atlas.semantic_bound ? "YES" : "no");
            ImGui::TextUnformatted(
                "Copy path: framebuffer layer blit");
            ImGui::Text(
                "FBO complete at last ReShade pass: %s",
                atlas.fbo_complete_last_effects ? "YES" : "no");
            ImGui::Text(
                "Copy valid at last ReShade pass: %s",
                atlas.copy_valid_last_effects ? "YES" : "no");
            ImGui::Text(
                "Atlas copies total: %llu",
                static_cast<unsigned long long>(atlas.copy_count));
            ImGui::Text(
                "Last GL copy error: 0x%04X",
                static_cast<unsigned int>(atlas.last_gl_error));
        }
        ImGui::Unindent();

        ImGui::Spacing();
        ImGui::TextUnformatted("ReflectionProbes metadata readback:");
        ImGui::Indent();
        ImGui::Text(
            "Readback: %s",
            metadata.readback_ok ? "YES" : "no");
        if (metadata.readback_ok)
        {
            ImGui::Text(
                "refmapCount: %d  (%s)",
                metadata.refmap_count,
                metadata.count_valid ? "valid" : "INVALID");
            ImGui::Text(
                "Hero shape / mip count / probe count: %d / %d / %d",
                metadata.hero_shape,
                metadata.hero_mip_count,
                metadata.hero_probe_count);
            ImGui::Text(
                "refSphere[0]: %.3f %.3f %.3f %.3f",
                metadata.first_sphere[0],
                metadata.first_sphere[1],
                metadata.first_sphere[2],
                metadata.first_sphere[3]);
            ImGui::Text(
                "refParams[0]: %.3f %.3f %.3f %.3f",
                metadata.first_params[0],
                metadata.first_params[1],
                metadata.first_params[2],
                metadata.first_params[3]);
            ImGui::Text(
                "refIndex[0]: %d %d %d %d",
                metadata.first_index[0],
                metadata.first_index[1],
                metadata.first_index[2],
                metadata.first_index[3]);
        }
        ImGui::Unindent();

        ImGui::Separator();

        const bool ready =
            pair.found &&
            pair.same_draw_valid &&
            pair.ubo_exact &&
            atlas.copy_valid_last_effects &&
            atlas.semantic_bound &&
            metadata.readback_ok &&
            metadata.count_valid;

        ImGui::Text(
            "Probe bridge readiness: %s",
            ready
                ? "IRRADIANCE ATLAS + METADATA CONFIRMED"
                : "waiting for paired copy + metadata");

        ImGui::Spacing();
        ImGui::PushTextWrapPos();
        ImGui::TextUnformatted(
            "v0.3a chooses irradianceProbes and reflectionProbes from the SAME Firestorm draw and requires Firestorm's exact 49,248-byte ReflectionProbes UBO. "
            "The live runtime showed that reflection and irradiance cube-array capacities do not have to differ by exactly two, so that v0.3 assumption has been removed. "
            "The authoritative 16x16 single-mip irradianceProbes array is copied face-by-face through framebuffer layer blits into an add-on-owned 2D atlas (six faces per row) and exposed to ReShade as SL_IRRADIANCE_ATLAS. "
            "The UBO is read back so the next stage can reproduce Firestorm's spatial probe selection instead of inventing SSGI.");
        ImGui::PopTextWrapPos();
    }
}

extern "C" __declspec(dllexport) const char *NAME = "SL Probe Bridge";
extern "C" __declspec(dllexport) const char *DESCRIPTION =
    "Copies a same-draw Firestorm irradiance probe cube array into a private ReShade atlas and reads ReflectionProbes metadata.";

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        if (!reshade::register_addon(module))
            return FALSE;

        reshade::register_overlay("SL Probe Bridge", draw_overlay);

        reshade::register_event<reshade::addon_event::init_device>(on_init_device);
        reshade::register_event<reshade::addon_event::destroy_device>(on_destroy_device);
        reshade::register_event<reshade::addon_event::init_effect_runtime>(on_init_effect_runtime);
        reshade::register_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_effect_runtime);
        reshade::register_event<reshade::addon_event::draw>(on_draw);
        reshade::register_event<reshade::addon_event::draw_indexed>(on_draw_indexed);
        reshade::register_event<reshade::addon_event::present>(on_present);
        reshade::register_event<reshade::addon_event::reshade_begin_effects>(on_begin_effects);
        reshade::register_event<reshade::addon_event::reshade_finish_effects>(on_finish_effects);
        break;

    case DLL_PROCESS_DETACH:
        reshade::unregister_event<reshade::addon_event::reshade_finish_effects>(on_finish_effects);
        reshade::unregister_event<reshade::addon_event::reshade_begin_effects>(on_begin_effects);
        reshade::unregister_event<reshade::addon_event::present>(on_present);
        reshade::unregister_event<reshade::addon_event::draw_indexed>(on_draw_indexed);
        reshade::unregister_event<reshade::addon_event::draw>(on_draw);
        reshade::unregister_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_effect_runtime);
        reshade::unregister_event<reshade::addon_event::init_effect_runtime>(on_init_effect_runtime);
        reshade::unregister_event<reshade::addon_event::destroy_device>(on_destroy_device);
        reshade::unregister_event<reshade::addon_event::init_device>(on_init_device);

        reshade::unregister_overlay("SL Probe Bridge", draw_overlay);
        reshade::unregister_addon(module);
        break;
    }

    return TRUE;
}
