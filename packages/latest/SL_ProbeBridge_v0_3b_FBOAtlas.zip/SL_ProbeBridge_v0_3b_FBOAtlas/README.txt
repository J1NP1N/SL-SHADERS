SL Probe Bridge v0.3b - FBO Atlas Copy
=====================================

The v0.3a panel showed that source discovery and metadata are working, but the
private atlas handoff failed at the direct image-copy step:

    Private irradiance atlas: Created YES
    ReflectionProbes metadata readback: YES
    Last GL copy error: 0x0501
    Copy valid: no

v0.3b changes only that handoff layer.

Instead of direct cube-array -> 2D image copy, each Firestorm irradiance face is
attached to a read framebuffer and blitted into its 16x16 tile in the private
2D atlas.

First test:
    SL Probe Irradiance v0.3b - Firestorm Atlas

Add-ons -> SL Probe Bridge should retain all same-draw / UBO YES results.

The decisive new lines are:

    Copy path: framebuffer layer blit
    FBO complete at last ReShade pass: YES
    Copy valid at last ReShade pass: YES
    Atlas copies total: increasing
    Last GL copy error: 0x0000
    Semantic SL_IRRADIANCE_ATLAS bound: YES

Then:
    Display Mode = Input status
        expected cyan

    Display Mode = Atlas overview
        expected Firestorm's low-resolution irradiance probe faces

This is still diagnostic only; it does not yet apply probe lighting.
