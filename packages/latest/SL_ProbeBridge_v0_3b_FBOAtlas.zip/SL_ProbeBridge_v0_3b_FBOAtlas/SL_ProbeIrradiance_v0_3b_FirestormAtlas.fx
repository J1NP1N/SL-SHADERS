#include "ReShade.fxh"

// SL Probe Irradiance Atlas v0.3b
//
// Diagnostic only. This visualizes the private copy of Firestorm's real
// irradianceProbes cube-map array. It does NOT yet perform spatial probe
// selection or add lighting to the scene.

uniform float SLProbeBridgeValid = 0.0;
uniform float4 SLProbeAtlasInfo = float4(0.0, 0.0, 0.0, 0.0);
uniform float SLProbeRefMapCount = 0.0;

uniform int SLProbeDisplayMode
<
    ui_label = "Display Mode";
    ui_type = "combo";
    ui_items =
        "Atlas overview\0"
        "Selected cube - six faces\0"
        "Input status\0";
> = 0;

uniform int SLProbeCubeIndex
<
    ui_label = "Cube Array Index";
    ui_type = "drag";
    ui_min = 0;
    ui_max = 255;
    ui_step = 1;
> = 0;

uniform float SLProbeExposure
<
    ui_label = "Diagnostic Exposure";
    ui_type = "drag";
    ui_min = 0.05;
    ui_max = 8.0;
    ui_step = 0.05;
> = 1.0;

uniform bool SLProbeFlipV
<
    ui_label = "Flip Atlas V";
    ui_tooltip = "Diagnostic orientation switch only. Does not change the captured data.";
> = false;

texture SLIrradianceAtlasTex : SL_IRRADIANCE_ATLAS;

sampler SLIrradianceAtlasSampler
{
    Texture = SLIrradianceAtlasTex;
    AddressU = CLAMP;
    AddressV = CLAMP;
    MinFilter = POINT;
    MagFilter = POINT;
    MipFilter = POINT;
};

float3 DisplayMap(float3 c)
{
    c = max(c, 0.0) * SLProbeExposure;

    // Simple diagnostic shoulder so HDR irradiance values remain visible.
    return c / (1.0 + c);
}

bool AtlasReady()
{
    return
        SLProbeBridgeValid > 0.5 &&
        SLProbeAtlasInfo.x >= 6.0 &&
        SLProbeAtlasInfo.y >= 1.0 &&
        SLProbeAtlasInfo.z >= 1.0 &&
        SLProbeAtlasInfo.w >= 1.0;
}

float2 MaybeFlipV(float2 uv)
{
    if (SLProbeFlipV)
        uv.y = 1.0 - uv.y;

    return uv;
}

float4 AtlasOverview(float2 screenUV)
{
    float atlasAspect =
        SLProbeAtlasInfo.x /
        max(SLProbeAtlasInfo.y, 1.0);

    float screenAspect =
        (float)BUFFER_WIDTH /
        max((float)BUFFER_HEIGHT, 1.0);

    float2 uv = screenUV;

    if (screenAspect > atlasAspect)
    {
        float widthFraction =
            atlasAspect / screenAspect;

        float left =
            0.5 * (1.0 - widthFraction);

        if (uv.x < left ||
            uv.x > 1.0 - left)
            return float4(0.0, 0.0, 0.0, 1.0);

        uv.x =
            (uv.x - left) /
            max(widthFraction, 1e-6);
    }
    else
    {
        float heightFraction =
            screenAspect / atlasAspect;

        float top =
            0.5 * (1.0 - heightFraction);

        if (uv.y < top ||
            uv.y > 1.0 - top)
            return float4(0.0, 0.0, 0.0, 1.0);

        uv.y =
            (uv.y - top) /
            max(heightFraction, 1e-6);
    }

    uv = MaybeFlipV(uv);

    return float4(
        DisplayMap(
            tex2D(
                SLIrradianceAtlasSampler,
                uv).rgb),
        1.0);
}

float4 SelectedCubeFaces(float2 screenUV)
{
    float cubeCount =
        max(SLProbeAtlasInfo.z, 1.0);

    float cubeIndex =
        clamp(
            (float)SLProbeCubeIndex,
            0.0,
            cubeCount - 1.0);

    // Display one Firestorm cube as a 6:1 strip, preserving texel aspect.
    float stripAspect = 6.0;
    float screenAspect =
        (float)BUFFER_WIDTH /
        max((float)BUFFER_HEIGHT, 1.0);

    float2 uv = screenUV;

    if (screenAspect > stripAspect)
    {
        float widthFraction =
            stripAspect / screenAspect;
        float left =
            0.5 * (1.0 - widthFraction);

        if (uv.x < left ||
            uv.x > 1.0 - left)
            return float4(0.0, 0.0, 0.0, 1.0);

        uv.x =
            (uv.x - left) /
            max(widthFraction, 1e-6);
    }
    else
    {
        float heightFraction =
            screenAspect / stripAspect;
        float top =
            0.5 * (1.0 - heightFraction);

        if (uv.y < top ||
            uv.y > 1.0 - top)
            return float4(0.0, 0.0, 0.0, 1.0);

        uv.y =
            (uv.y - top) /
            max(heightFraction, 1e-6);
    }

    float2 atlasUV;

    // Atlas columns are +X, -X, +Y, -Y, +Z, -Z because Firestorm's
    // LLCubeMapArray layer order follows OpenGL face-layer order.
    atlasUV.x = uv.x;
    atlasUV.y =
        (cubeIndex + uv.y) /
        cubeCount;

    atlasUV = MaybeFlipV(atlasUV);

    return float4(
        DisplayMap(
            tex2D(
                SLIrradianceAtlasSampler,
                atlasUV).rgb),
        1.0);
}

float4 ProbeAtlasPS(
    float4 pos : SV_Position,
    float2 uv : TEXCOORD) : SV_Target
{
    if (SLProbeDisplayMode == 2)
    {
        // Cyan means:
        // private irradiance atlas copied + semantic bound + UBO readback valid.
        bool ready = AtlasReady();

        return float4(
            ready ? 0.0 : 1.0,
            ready ? 1.0 : 0.0,
            ready ? 1.0 : 0.0,
            1.0);
    }

    if (!AtlasReady())
    {
        return float4(
            1.0,
            0.0,
            0.0,
            1.0);
    }

    if (SLProbeDisplayMode == 1)
        return SelectedCubeFaces(uv);

    return AtlasOverview(uv);
}

technique SL_ProbeIrradianceAtlas_v0_3b
<
    ui_label = "SL Probe Irradiance v0.3b - Firestorm Atlas";
>
{
    pass Visualize
    {
        VertexShader = PostProcessVS;
        PixelShader = ProbeAtlasPS;
    }
}
